
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import { Card } from './components/Card';
import { Navbar } from './components/Navbar';
import { CardRegister } from './components/register/CardRegister';
import { Porfile } from './components/student/Porfile';

function App() {
  return (
    <BrowserRouter>
      <div className="App container-fluid">
        <Navbar />
        <Routes>
          <Route path='/' element={<CardRegister />} />
          <Route path='/login' element={<Card />} />
          <Route path='/profile' element ={<Porfile/>}/>
        </Routes>
        
      </div>
    

    </BrowserRouter>
  );
}

export default App;
