import React from 'react'
import { Link } from 'react-router-dom';

export const Register = () => {
    return (
        <div>  <form>
            <div className="row mb-3">
                <label htmlFor="inputEmail3" className="col-sm-2 col-form-label">Username</label>
                <div className="col-sm-10">
                    <input type="text" className="form-control" id="inputEmail3" required />
                </div>
            </div>
            <div className="row mb-3">
                <label htmlFor="inputPassword3" className="col-sm-2 col-form-label">Password</label>
                <div className="col-sm-10">
                    <input type="password" className="form-control" id="inputPassword3" required />
                </div>
            </div>
            <div className="row mb-3">
                <label htmlFor="inputPassword3" className="col-sm-2 col-form-label">Confirm Password</label>
                <div className="col-sm-10">
                    <input type="password" className="form-control" id="inputPassword3" required />
                </div>
            </div>
    
            <button type="submit" className="btn btn-dark">Sign Up</button>
            <Link to='/login' className="btn btn-outline-dark ms-2">Sign in</Link>
        </form></div>
    )
}
