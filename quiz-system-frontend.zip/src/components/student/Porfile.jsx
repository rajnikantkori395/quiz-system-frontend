import React, { Profiler, useState } from 'react'
import { Footer } from './Footer'
import { Question } from './Question'

export const Porfile = () => {
    const [name, setName] = useState();

    return (
        <>
            <div className='row align-items-center justify-content-center m-5'>
                <div className="card mt-3">
                    <div className="card-body">
                        <h5 className="card-title">Student Name : {name}</h5>
                        <Question />
                    </div>
                </div>

            </div>
            <Footer />
        </>

    )
}
