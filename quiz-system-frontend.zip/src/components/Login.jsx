import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';

export const Login = () => {
    const [username, setUsername] = useState('')
    const [password, setPassword] = useState('')
    const [token ,setToken] =useState(null);
    const navigate = useNavigate();

    const handleSubmit = async(e) => {
        e.preventDefault()
        let result = await axios("/auth/user/login",{
          method:'post',
          data:JSON.stringify({username,password}),
          headers:{
            'content-type' : 'application/json'
          }
        })
        .then((res)=>{
            setToken(res.data);
        })
        .catch((err)=>{
            alert('cant connect to server',err);
        }) 

        if(token){
            navigate('/profile',{
                state:{
                    token:token
                }
            })
        }
    }

    return (
        <div>
            <form onSubmit={handleSubmit}>
                <div className="row mb-3">
                    <label htmlFor="inputEmail3" className="col-sm-2 col-form-label">Username</label>
                    <div className="col-sm-10">
                        <input type="text" className="form-control" id="inputEmail3" onChange={(e)=>setUsername(e.target.value)} required />
                    </div>
                </div>
                <div className="row mb-3">
                    <label htmlFor="inputPassword3" className="col-sm-2 col-form-label">Password</label>
                    <div className="col-sm-10">
                        <input type="password" className="form-control" id="inputPassword3" onChange={(e)=>setPassword(e.target.value)} required />
                    </div>
                </div>
                <div className="row mb-3">
                    <label htmlFor="role" className="col-sm-2 col-form-label">User Role</label>
                    <div className="col-sm-10">
                        <select class="form-select" id="role" aria-label="Default select example">
                            <option defaultValue=''>select</option>
                            <option value="student">Student</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>

                </div>
                <button type="submit" className="btn btn-dark">Sign in</button>
                <Link to='/' className="btn btn-outline-dark ms-2">Sign up</Link>
            </form>
        </div>
    )
}
